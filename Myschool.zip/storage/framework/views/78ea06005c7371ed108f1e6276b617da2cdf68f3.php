
        <!-- start banner Area -->
<?php $__env->startSection('contenu'); ?>
<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    


        <section class="banner-area relative" id="home">
            <div class="overlay overlay-bg"></div>	
            <div class="container">
                <div class="row fullscreen d-flex align-items-center justify-content-between">
                    <div class="banner-content col-lg-9 col-md-12">
                        <h1 class="text-uppercase">
                           <?php echo e($slider->description1); ?>		
                        </h1>
                        <p class="pt-10 pb-10">
                            <?php echo e($slider->description2); ?>

                        </p>
                        <a href="#" class="primary-btn text-uppercase">Get Started</a>
                    </div>										
                </div>
            </div>					
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- End banner Area -->

        
                
        <!-- Start popular-course Area -->
            <div class="container mt-5">
                <div class="row d-flex justify-content-center">
                    <div class="menu-content pb-70 col-lg-8">
                        <div class="title text-center">
                            <h1 class="mb-10">Popular Courses we offer</h1>
                            <p>There is a moment in the life of any aspiring.</p>
                        </div>
                    </div>
                </div>
               
                    
           					
                <div class="row">
                    <div class="active-popular-carusel">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-popular-carusel">
                            <div class="thumb-wrap relative">
                                <div class="thumb relative">
                                    <div class="overlay overlay-bg"></div>	
                                    <img class="img-fluid" src="<?php echo e(asset('/storage/course_images/'.$course->image)); ?>" alt="">
                                </div>
                           								
                            </div>
                            <div class="details">
                                <a href="#">
                                    <h4>
                                     <?php echo e($course->name); ?>

                                    </h4>
                                </a>
                              
                            </div>
                        </div>	
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
              							
                    </div>
                </div>
               
            </div>	
      
        <section class="upcoming-event-area section-gap">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="menu-content pb-70 col-lg-8">
                        <div class="title text-center">
                            <h1 class="mb-10">Upcoming Events of our Institute</h1>
                            <p>If you are a serious astronomy fanatic like a lot of us</p>
                        </div>
                    </div>
                </div>								
                <div class="row">
                    <div class="active-upcoming-event-carusel">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-carusel row align-items-center">
                            <div class="col-12 col-md-6 thumb">
                                <img class="img-responsive" width="300px" height="200px" src="<?php echo e(asset('/storage/event_images/'.$event->image)); ?>" alt="">
                            </div>
                            <div class="detials col-12 col-md-6">
                                <p><?php echo e($event->date); ?></p>
                                <a href="#"><h4><?php echo e($event->title); ?></h4></a>
                                <p>
                                   <?php echo e($event->description); ?>

                                </p>
                            </div>
                        </div>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

                    </div>
                </div>
            </div>	
        </section>
        <!-- End upcoming-event Area -->
                    
        <!-- Start review Area -->
        <section class="review-area section-gap relative">
            <div class="row d-flex justify-content-center">
                <div class="menu-content pb-70 col-lg-8">
                    <div class="title text-center">
                        <h1 class="mb-10">What our students like about our institutions</h1>
                        <p>There is a moment in the life of any aspiring.</p>
                    </div>
                </div>
            </div>
            <div class="overlay overlay-bg"></div>
            <div class="container">				
                <div class="row">
                    <div class="active-review-carusel">
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Fannie Rowe</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Hulda Sutton</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Fannie Rowe</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Hulda Sutton</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>	
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Fannie Rowe</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Hulda Sutton</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <img src="<?php echo e(asset('frontend/img/r1.png')); ?>" alt="">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Fannie Rowe</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>
                        <div class="single-review item">
                            <div class="title justify-content-start d-flex">
                                <a href="#"><h4>Hulda Sutton</h4></a>
                                <div class="star">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star"></span>
                                    <span class="fa fa-star"></span>
                                </div>
                            </div>
                            <p>
                                Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker. Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker.
                            </p>
                        </div>																												
                    </div>
                </div>
            </div>	
        </section>
        <!-- End review Area -->	
        
      
        <!-- End cta-one Area -->

        <!-- Start blog Area -->
        <section class="blog-area section-gap" id="blog">
            <div class="container">
                <div class="row d-flex justify-content-center">
                    <div class="menu-content pb-70 col-lg-8">
                        <div class="title text-center">
                            <h1 class="mb-10">Latest posts from our Blog</h1>
                            <p>In the history of modern astronomy there is.</p>
                        </div>
                    </div>
                </div>					
                <div class="row">
                    <?php $__currentLoopData = $latestgalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latestgallerie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 single-blog">
                        <div class="thumb">
                            <img class="img-fluid" src="<?php echo e(asset('/storage/gallery_images/'.$latestgallerie->image_gallery)); ?>" alt="">								
                        </div>
                        <a href="blog-single.html">
                            <h5><?php echo e($latestgallerie->title); ?></h5>
                        </a>
                        
                    </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   						
                </div>
            </div>	
        </section>
        <!-- End blog Area -->			
        

<?php $__env->stopSection(); ?>
        <!-- End cta-two Area -->
                    
     
<?php echo $__env->make('./frontend/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\Myschool\resources\views/frontend/home.blade.php ENDPATH**/ ?>