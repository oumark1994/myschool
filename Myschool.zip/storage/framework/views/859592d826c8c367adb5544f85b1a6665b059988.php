
<?php $__env->startSection('contenu'); ?>
<section class="banner-area relative about-banner" id="home">	
    <div class="overlay overlay-bg"></div>
    <div class="container">				
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    Events				
                </h1>	
                <p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="<?php echo e(url('/events')); ?>"> Events</a></p>
            </div>	
        </div>
    </div>
</section>
<!-- End banner Area -->	
    
<!-- Start events-list Area -->
<section class="events-list-area section-gap event-page-lists">
    <div class="container">
        <div class="row align-items-center">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 pb-30">
                <div class="single-carusel row align-items-center">
                    <div class="col-12 col-md-6 thumb">
                        <img class="img-fluid" src="<?php echo e(asset('/storage/event_images/'.$event->image)); ?>" alt="">
                    </div>
                    <div class="detials col-12 col-md-6">
                        <p><?php echo e($event->date); ?></p>
                        <a href="event-details.html"><h4><?php echo e($event->title); ?></h4></a>
                        <p>
                            <?php echo e($event->description); ?>

                        </p>
                    </div>
                </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
         																		
        </div>
    </div>	
</section>
<!-- End events-list Area -->
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('./frontend/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\Myschool\resources\views/frontend/events.blade.php ENDPATH**/ ?>