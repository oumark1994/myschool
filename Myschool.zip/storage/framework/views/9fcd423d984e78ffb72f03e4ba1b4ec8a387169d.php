
<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/fav.png">
    <!-- Author Met
        a -->
    <meta name="author" content="colorlib">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title><?php echo e($setting->name); ?></title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
        CSS
        ============================================= -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/linearicons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/magnific-popup.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/nice-select.css')); ?>">							
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl.carousel.css')); ?>">			
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/jquery-ui.css')); ?>">			
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/main.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>	
    </head>
    <body>
      
      <header id="header" id="home">
          <div class="header-top">
              <div class="container">
                  <div class="row">
                      <div class="col-lg-6 col-sm-6 col-8 header-top-left no-padding">
                          <ul>
                            <li><a href="<?php echo e($setting->facebook_link); ?>"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="<?php echo e($setting->twitter_link); ?>"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="<?php echo e($setting->instagram_link); ?>"><i class="fa fa-instagram"></i></a></li>
                          </ul>			
                      </div>
                      <div class="col-lg-6 col-sm-6 col-4 header-top-right no-padding">
                          <a href="tel:+953 012 3654 896"><span class="lnr lnr-phone-handset"></span> <span class="text"><?php echo e($setting->mobile); ?></span></a>
                          <a href="mailto:support@colorlib.com"><span class="lnr lnr-envelope"></span> <span class="text"><?php echo e($setting->email); ?></span></a>			
                      </div>
                  </div>			  					
              </div>
        </div>
        <div class="container main-menu">
            <div class="row align-items-center justify-content-between d-flex">
              <div id="logo">
                <a href="index.html"><img src="<?php echo e(asset('/storage/logo_images/'.$setting->logo)); ?>" alt="" title="" width="45px" height="45px" /></a>
              </div>
              <nav id="nav-menu-container">
                <ul class="nav-menu">
                  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                  <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
                  <li><a href="<?php echo e(url('/courses')); ?>">Courses</a></li>
                  <li><a href="<?php echo e(url('/events')); ?>">Events</a></li>
                  <li><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>
                				          					          		          
                  <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                </ul>
              </nav><!-- #nav-menu-container -->		    		
            </div>
        </div>
      </header><!-- #header -->
      <?php echo $__env->yieldContent('contenu'); ?>
  <!-- start footer Area -->	
   <footer class="footer-area section-gap">
    <div class="container">
        <div class="row">
      
            <div class="col-lg-2 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h4>Quick Menu</h4>
                    <ul>
                        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                        <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
                        <li><a href="<?php echo e(url('/courses')); ?>">Courses</a></li>                   
                          

                    </ul>
                                							
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h4></h4>
                    <ul>
                        <li><a href="<?php echo e(url('/events')); ?>">Events</a></li>
                        <li><a href="<?php echo e(url('/gallery')); ?>">Gallery</a></li>    

                        <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
                    </ul>								
                </div>
            </div>
    																	
            <div class="col-lg-4  col-md-6 col-sm-6">
                <div class="single-footer-widget">
                    <h4>Newsletter</h4>
                    <p>Stay update with our latest</p>
                    <div class="" id="mc_embed_signup">
                         <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get">
                          <div class="input-group">
                            <input type="text" class="form-control" name="EMAIL" placeholder="Enter Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email Address '" required="" type="email">
                            <div class="input-group-btn">
                              <button class="btn btn-default" type="submit">
                                <span class="lnr lnr-arrow-right"></span>
                              </button>    
                            </div>
                                <div class="info"></div>  
                          </div>
                        </form> 
                    </div>
                </div>
            </div>											
        </div>
        <div class="footer-bottom row align-items-center justify-content-between">
            <p class="footer-text m-0 col-lg-6 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved by kollatec
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
            <div class="col-lg-6 col-sm-12 footer-social">
                
                    <a href="<?php echo e($setting->facebook_link); ?>"><i class="fa fa-facebook"></i></a>
                    <a href="<?php echo e($setting->twitter_link); ?>"><i class="fa fa-twitter"></i></a>
                    <a href="<?php echo e($setting->instagram_link); ?>"><i class="fa fa-instagram"></i></a>
                  
            </div>
        </div>						
    </div>
</footer>	
<!-- End footer Area -->	


<script src="<?php echo e(asset('frontend/js/vendor/jquery-2.2.4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('frontend/js/vendor/bootstrap.min.js')); ?>"></script>			
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  <script src="<?php echo e(asset('frontend/js/easing.min.js')); ?>"></script>			
<script src="<?php echo e(asset('frontend/js/hoverIntent.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/superfish.min.js')); ?>"></script>	
<script src="<?php echo e(asset('frontend/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.magnific-popup.min.js')); ?>"></script>	
<script src="<?php echo e(asset('frontend/js/jquery.tabs.min.js')); ?>"></script>						
<script src="<?php echo e(asset('frontend/js/jquery.nice-select.min.js')); ?>"></script>	
<script src="<?php echo e(asset('frontend/js/owl.carousel.min.js')); ?>"></script>									
<script src="<?php echo e(asset('frontend/js/mail-script.js')); ?>"></script>	
<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>	
</body>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</html>
<?php /**PATH C:\Users\Oumark\Desktop\laravel\Myschool\resources\views///frontend/app.blade.php ENDPATH**/ ?>