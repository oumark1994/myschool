
<?php $__env->startSection('contenu'); ?>
<section class="banner-area relative about-banner" id="home">	
    <div class="overlay overlay-bg"></div>
    <div class="container">				
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    About Us				
                </h1>	
                <p class="text-white link-nav"><a href="<?php echo e(url('/')); ?>">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="<?php echo e(url('/about')); ?>"> About Us</a></p>
            </div>	
        </div>
    </div>
</section>
<!-- End banner Area -->	

<!-- Start feature Area -->
<section class="feature-area pb-120">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="single-feature">
                    <div class="title">
                        <h4><?php echo e($facility->title); ?></h4>
                    </div>
                    <div class="desc-wrap">
                        <p>
                           <?php echo e($facility->description); ?>

                        </p>
                    </div>
                </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        												
        </div>
    </div>	
</section>
<!-- End feature Area -->		

<!-- Start info Area -->
<section class="info-area pb-120">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-lg-6 no-padding info-area-left">
                <img class="img-fluid" src="<?php echo e(asset('frontend/img/hkll.jpg')); ?>" alt="">
            </div>
            <div class="col-lg-6 info-area-right">
                <h1>Who we are
                to Serave the nation</h1>
                <p>inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace. That’s why it’s crucial that, as women, our behavior on the job is beyond reproach.</p>
                <br>
                <p>
                    inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace. That’s why it’s crucial that, as women, our behavior on the job is beyond reproach. inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace. That’s why it’s crucial that, as women, our behavior on the job is beyond reproach.
                </p>
            </div>
        </div>
    </div>	
</section>
<!-- End info Area -->	

<!-- Start course-mission Area -->

<!-- End course-mission Area -->
        


<section class="search-course-area relative">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-12 p-5 col-md-12 search-course-left">
                <h1 class="text-white text-center">
                    Get reduced fee <br>
                    during this Summer!
                </h1>
                <p>
                    inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace. That’s why it’s crucial that, as women, our behavior on the job is beyond reproach.
                </p>
                <div class="row details-content">
                    <div class="col single-detials">
                        <span class="lnr lnr-graduation-hat"></span>
                        <a href="#"><h4>Expert Instructors</h4></a>		
                        <p>
                            Usage of the Internet is becoming more common due to rapid advancement of technology and power.
                        </p>						
                    </div>
                    <div class="col single-detials">
                        <span class="lnr lnr-license"></span>
                        <a href="#"><h4>Certification</h4></a>		
                        <p>
                            Usage of the Internet is becoming more common due to rapid advancement of technology and power.
                        </p>						
                    </div>								
                </div>
            </div>
            
        

     
        </div>
    </div>	
</section>
                                        


<!-- End search-course Area -->			

<!-- Start review Area -->

<!-- End review Area -->					


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./frontend/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\Myschool\resources\views/frontend/about.blade.php ENDPATH**/ ?>