
<?php $__env->startSection('contenu'); ?>

		    		

<div class="d-flex flex-column flex-row-fluid wrapper mt-10" id="kt_wrapper">

<!--begin::Card-->

 <div class="card card-custom mt-5">
	<div class="card-header flex-wrap border-0 pt-6 pb-0">
		<div class="card-title">
			<h3 class="card-label">
				Messages
			</h3>
		</div>
		<div class="card-toolbar">
			<!--begin::Dropdown-->
<div class="dropdown dropdown-inline mr-2">


	<!--begin::Dropdown Menu-->
	<div class="dropdown-menu dropdown-menu-sm dropdown-menu-right">
		<!--begin::Navigation-->
			
		<!--end::Navigation-->
	</div>
	<!--end::Dropdown Menu-->
</div>
<!--end::Dropdown-->

<!--begin::Button-->

<!--end::Button-->
		</div>
	
<?php echo e(Form::hidden('',$increment=1)); ?>

</div>
</div>
<div class="card-body">
<?php if(Session::has('status')): ?>
<div class="alert alert-success">
<?php echo e(Session::get('status')); ?>

</div>
<?php endif; ?>
<!--begin: Search Form-->
<!--begin::Search Form-->


<!--begin: Datatable-->

<!--begin: Datatable-->

<div class="table-responsive">
	<table class="table table-striped table-sm">
	  <thead>
		<tr>
		  <th scope="col">#</th>
		  <th scope="col">Name</th>

		  <th scope="col">Email</th>
		  <th scope="col">Subject</th>
		  <th scope="col">Message</th>
		  <th scope="col" colspan="3">Actions</th>
		</tr>
	  </thead>
	  <tbody>
		<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  
		 
		<tr>
			<td><?php echo e($increment); ?></td>
			<td><?php echo e($message->name); ?></td>
			<td><?php echo e($message->email); ?></td>
			<td><?php echo e($message->subject); ?></td>
			<td><?php echo e($message->message); ?></td>
			<td>
			  <a href="<?php echo e(url('/deletemessage/'.$message->id)); ?>" class="btn btn-danger font-weight-bold mr-2">
				  <i class="flaticon-delete-1 icon-sm"></i>
			  </a>

			</td>
		  </tr>
		  <?php echo e(Form::hidden('',$increment=$increment + 1)); ?>

		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  
		</tr>
			  </tbody>
			</table>
		  </div>
		<!--end: Datatable-->
	</div>
	</div>
</div>
<!--end::Card-->
		</div>
		<!--end::Container-->
	</div>
<!--end::Entry-->
</div>
				</div>
				<!--end::Content-->
                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('./backend/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oumark\Desktop\laravel\Myschool\resources\views/backend/messages.blade.php ENDPATH**/ ?>